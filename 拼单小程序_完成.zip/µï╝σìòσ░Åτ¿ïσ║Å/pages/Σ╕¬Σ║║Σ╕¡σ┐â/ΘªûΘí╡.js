var sliderWidth = 96; // 需要设置slider的宽度，用于计算中间位置
var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var app = getApp();
var that;

Page({
  data: {
    tabs: ["已完成拼单", "未完成拼单",],
    activeIndex: 1,
    sliderOffset: 0,
    sliderLeft: 0,
    pindanList: [],
    pindanListfinished: [],
    pincheList: [],
    pincheListfinished: [],
    pinfangList: [],
    pinfangListfinished: []
  },
  onLoad: function () {
    var that = this;
    that = this;

    wx.showShareMenu({
      withShareTicket: true //要求小程序返回分享目标信息
    })

    var k = 'http://bmob-cdn-12917.b0.upaiyun.com/2017/07/18/d99d3bb7400cb1ed808f34896bff6fcc.jpg';

    var newUrl = k.replace("http://bmob-cdn-12917.b0.upaiyun.com", "https://bmob-cdn-12917.bmobcloud.com")

    console.log(newUrl);
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          sliderLeft: (res.windowWidth / that.data.tabs.length - sliderWidth) / 2,
          sliderOffset: res.windowWidth / that.data.tabs.length * that.data.activeIndex
        });
      }
    });
  },
  onPullDownRefresh: function () {
    wx.showNavigationBarLoading() //在标题栏中显示加载

    //模拟加载
    setTimeout(function () {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },
  onShow: function () {
    gettakeoutList(this);
    gettakeoutfinishedList(this);
    getpinchefinishedlist(this);
    getpinchelist(this);
    getpinfangfinishedlist(this);
    getpinfanglist(this)
  },
  tabClick: function (e) {
    this.setData({
      sliderOffset: e.currentTarget.offsetLeft,
      activeIndex: e.currentTarget.id
    });
  }

});

function gettakeoutfinishedList(t, k) {
  that = t;
  var pindan = Bmob.Object.extend("takeOut");
  var query = new Bmob.Query(pindan);


  query.equalTo("finished", "true");
  query.equalTo("tel", app.globalData.userTel);



  //query.descending('createdAt');
  //query.include("own")
  // 查询所有数据
  //query.limit(that.data.limit);

  //var mainQuery = Bmob.Query.or(query, query1);
  var mainQuery = query;
  mainQuery.find({
    success: function (results) {
      // 循环处理查询到的数据
      console.log(results);
      that.setData({
        pindanListfinished: results
      })
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}
function gettakeoutList(t, k) {
  that = t;
  var pindan = Bmob.Object.extend("takeOut");
  var query = new Bmob.Query(pindan);


  query.equalTo("finished", "false");
  query.equalTo("tel", app.globalData.userTel);



  //query.descending('createdAt');
  //query.include("own")
  // 查询所有数据
  //query.limit(that.data.limit);

  //var mainQuery = Bmob.Query.or(query, query1);
  var mainQuery = query;
  mainQuery.find({
    success: function (results) {
      // 循环处理查询到的数据
      console.log(results);
      that.setData({
        pindanList: results
      })
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}
function getpinchefinishedlist(t, k) {
  that = t;
  var pinche = Bmob.Object.extend("takecar");
  var query = new Bmob.Query(pinche);


  query.equalTo("finished", "true");
  query.equalTo("tel", app.globalData.userTel);



  //query.descending('createdAt');
  //query.include("own")
  // 查询所有数据
  //query.limit(that.data.limit);

  //var mainQuery = Bmob.Query.or(query, query1);
  var mainQuery = query;
  mainQuery.find({
    success: function (results) {
      // 循环处理查询到的数据
      console.log(results);
      that.setData({
        pincheListfinished: results
      })
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}

function getpinchelist(t, k) {
  that = t;
  var pinche = Bmob.Object.extend("takecar");
  var query = new Bmob.Query(pinche);


  query.equalTo("finished", "false");
  query.equalTo("tel", app.globalData.userTel);



  //query.descending('createdAt');
  //query.include("own")
  // 查询所有数据
  //query.limit(that.data.limit);

  //var mainQuery = Bmob.Query.or(query, query1);
  var mainQuery = query;
  mainQuery.find({
    success: function (results) {
      // 循环处理查询到的数据
      console.log(results);
      that.setData({
        pincheList: results
      })
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}
function getpinfangfinishedlist(t, k) {
  that = t;
  var pinche = Bmob.Object.extend("house");
  var query = new Bmob.Query(pinche);


  query.equalTo("finished", "true");
  query.equalTo("tel", app.globalData.userTel);



  //query.descending('createdAt');
  //query.include("own")
  // 查询所有数据
  //query.limit(that.data.limit);

  //var mainQuery = Bmob.Query.or(query, query1);
  var mainQuery = query;
  mainQuery.find({
    success: function (results) {
      // 循环处理查询到的数据
      console.log(results);
      that.setData({
        pinfangListfinished: results
      })
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}

function getpinfanglist(t, k) {
  that = t;
  var pinche = Bmob.Object.extend("house");
  var query = new Bmob.Query(pinche);


  query.equalTo("finished", "false");
  query.equalTo("tel", app.globalData.userTel);



  //query.descending('createdAt');
  //query.include("own")
  // 查询所有数据
  //query.limit(that.data.limit);

  //var mainQuery = Bmob.Query.or(query, query1);
  var mainQuery = query;
  mainQuery.find({
    success: function (results) {
      // 循环处理查询到的数据
      console.log(results);
      that.setData({
        pinfangList: results
      })
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}
