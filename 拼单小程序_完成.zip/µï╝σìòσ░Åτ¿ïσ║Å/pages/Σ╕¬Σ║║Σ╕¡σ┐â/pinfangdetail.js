var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
const WxParse = require('../../utils/wxParse/wxParse.js');

Page({
  data: {
    rows: {},
    id: ""
  },
  onLoad: function (e) {
    // 页面初始化 options为页面跳转所带来的参数
    console.log(e.objectId)
    var objectId = e.objectId;
    var that = this;

    // if (!e.objectId) {
    //   common.showTip("请重新进入", "loading");
    //   return false;
    // }
    var shopping = Bmob.Object.extend("house");
    var query = new Bmob.Query(shopping);
    query.get(objectId, {
      success: function (result) {
        console.log(result);
        WxParse.wxParse('content', 'html', result.get("content"), that);
        that.setData({
          rows: result,
          id: result.id
        })
        // The object was retrieved successfully.        
      },
      error: function (result, error) {
        console.log("查询失败");
      }
    });
  },
  finished: function () {
    var that = this;

    var Diary = Bmob.Object.extend("house");
    var query = new Bmob.Query(Diary);

    query.get(that.data.id, {
      success: function (result) {

        // 回调中可以取得这个 GameScore 对象的一个实例，然后就可以修改它了
        result.set('finished', "true");
        result.save();
        common.showTip('成功', 'success', function () {
          that.onShow();

        });
        // The object was retrieved successfully.
      },
      error: function (object, error) {

      }
    });
    wx.switchTab({
      url: '首页',
    })
  },
  clear: function () {
    var that = this;
    var waimai = Bmob.Object.extend("house");

    //创建查询对象，入口参数是对象类的实例
    var query = new Bmob.Query(waimai);
    query.get(that.data.id, {
      success: function (object) {
        // The object was retrieved successfully.
        object.destroy({
          success: function (deleteObject) {
            common.showTip('撤销成功', 'success', function () {
              that.onShow();
            });
          },
          error: function (object, error) {
            console.log('删除日记失败');
          }
        });
      },
      error: function (object, error) {
        console.log("query object fail");
      }
    });
    wx.switchTab({
      url: '首页',
    })
  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  }
})