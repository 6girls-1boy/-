Page({
  openFirstPage: function () {
    wx.switchTab({
      url: '首页',
    })
  }
});