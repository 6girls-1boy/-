var QQMapWX = require('qqmap-wx-jssdk.js');
var app = getApp();
Page({
  data: {
    inputShowed: false,
    inputVal: '',
    longitude: "121.47004",
    latitude: "31.23136",
    scale: "14"
  },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
  },
  clearInput: function () {
    this.setData({
      inputVal: ""
    });
  },
  inputTyping: function (e) {
    this.setData({
      inputVal: e.detail.value
    });
  },
  confirm: function (e) {
    wx.redirectTo({
      url: 'detail?str=' + this.data.inputVal,
    })
  },
  confirmTyping: function (e) {
    var that = this;
    this.setData({
      inputVal: e.detail.value
    })
    var demo = new QQMapWX({
      key: 'WRVBZ-ZQD6X-4UD4E-T7MOR-2UKCJ-VYFDG' // 必填
    });
    // 调用接口
    demo.geocoder({
      address: e.detail.value,
      success: function (res) {
        console.log(res);
        that.setData({
          longitude: res.result.location.lng,
          latitude: res.result.location.lat,
          "markers.longitude": res.result.location.lng,
          "markers.latitude": res.result.location.lat,
          scale: "18"
        })

      },
      fail: function (res) {
        console.log(res);
      },
      complete: function (res) {
        console.log(res);
      }
    });
  }
});