var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var app = getApp();

Page({
  data: {
    accounts: ["1", "2", "3"],
    accountIndex: 0,
    date: "",
    time: "",
    peopleNum: "1",
    aimAddress: "",
    longitude:"",
    latitude:"",
    report:""
  },
  onLoad:function(options){
    this.setData({
      aimAddress: options.str,
      longitude: options.lon,
      latitude: options.lat
    })
  },
  bindDateChange: function (e) {
    this.setData({
      date: e.detail.value
    })
  },
  bindTimeChange: function (e) {
    this.setData({
      time: e.detail.value
    })
  },
  bindAccountChange: function (e) {
    console.log('picker account 发生选择改变，携带值为', e.detail.value);

    this.setData({
      peopleNum: parseInt(e.detail.value,10)+1
    })
  },
  chooseAim:function(){
    wx.switchTab({
      url: '首页',
    })
  },
  typeIn:function(e){
    this.setData({
      report:e.detail.value
    })
  },
  sendMessage: function () {
    if (!this.data.peopleNum) {
      common.showTip("乘车人数不能为空", "loading");
    }
    else if (!this.data.date) {
      common.showTip("请选择拼车时间", "loading");
    }
    else {
      var Pinche = Bmob.Object.extend("takecar");
      var pinche = new Pinche();
      //添加数据，第一个入口参数是null
      pinche.save({
        place:this.data.aimAddress,
        peopleNum: this.data.peopleNum,
        willingDate: this.data.date,
        time: this.data.time,
        Report:this.data.report,
        tel:app.globalData.userTel,
        finished:"false"
      }, {
          success: function (result) {
            // 添加成功，返回成功之后的objectId（注意：返回的属性名字是id，不是objectId），你还可以在Bmob的Web管理后台看到对应的数据
   
            wx.navigateTo({
              url: 'msg_success',
            })
          },
          error: function (result, error) {
            // 添加失败
            wx.navigateTo({ url: 'msg_fail' });
          }
        })
    }
  },
})