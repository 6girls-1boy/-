var Bmob = require('../../utils/bmob.js');
var bmob = require('../../utils/bmob.js');
var that;

Page({
  data: {
    inputShowed: false,
    inputVal: "",
    pindanList: []
  },

  onLoad: function (options) {
    that = this;

    wx.showShareMenu({
      withShareTicket: true //要求小程序返回分享目标信息
    })

    var k = 'http://bmob-cdn-12917.b0.upaiyun.com/2017/07/18/d99d3bb7400cb1ed808f34896bff6fcc.jpg';

    var newUrl = k.replace("http://bmob-cdn-12917.b0.upaiyun.com", "https://bmob-cdn-12917.bmobcloud.com")

    console.log(newUrl);
  },
  onShow: function () {
    getList(this);
  },

  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
    getList(this)
  },
  clearInput: function () {
    this.setData({
      inputVal: ""
    });
    getList(this)
  },
  inputTyping: function (e) {
    this.setData({
      inputVal: e.detail.value
    });
    getList(this)
  },
  toAdd:function(){
    wx.navigateTo({
      url: 'add',
    })
  }

});

/*function showData(options, k) {
  that = options;
  var shopping = Bmob.Object.extend("shopping");
  var query = new Bmob.Query(shopping);
  query.equalTo("shopname", k);
  var mainQuery = query;
  mainQuery.find({
    success: function (results) {
      console.log("共查询到 " + results.length + " 条记录");
      // 循环处理查询到的数据
      for (var i = 0; i < results.length; i++) {
        var object = results[i];
        console.log(object.id + ' - ' + object.get('shopname'));
      }
      that.setData({
        results: results
      });
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}*/

function getList(t, k) {
  that = t;
  var pindan = Bmob.Object.extend("shopping");
  var query = new Bmob.Query(pindan);


  query.equalTo("shopname", k);

  //query.descending('createdAt');
  //query.include("own")
  // 查询所有数据
  //query.limit(that.data.limit);

  //var mainQuery = Bmob.Query.or(query, query1);
  var mainQuery = query;
  mainQuery.find({
    success: function (results) {
      // 循环处理查询到的数据
      console.log(results);
      that.setData({
        pindanList: results
      })
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}
