var that = this;
var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var i = 0;

Page({
  data: {
    files: [],
    files2: [],
    urlArr: [],
    picture: "",
    detail_Pic: "",
    shopName: "",
    shopAdd: "",
    startDate: "",
    Report: "",
    endDate: "",
    Tel: "",
    haspicture: false,
    hasdetailpicture: false
  },
  onLoad() {
    this.setData({
      Tel: getApp().globalData.userTel
    })
  },
  listenerSwitch: function (e) {
    var that = this;
    if (!e.detail.value) {
      that.setData({
        Tel: "发布者隐藏手机号"
      })

    }
    else {
      that.setData({
        Tel: getApp().globalData.userTel
      })
    }

  },
  typing1: function (e) {
    this.setData({
      shopName: e.detail.value
    })
  },
  typing2: function (e) {
    this.setData({
      shopAdd: e.detail.value
    })
  },
  bindDateChange1: function (e) {
    this.setData({
      startDate: e.detail.value
    })
  },
  bindDateChange2: function (e) {
    this.setData({
      endDate: e.detail.value
    })
  },
  report: function (e) {
    this.setData({
      Report: e.detail.value
    })
  },
  chooseImage1: function (e) {
    var that = this;
    // 注释这块是上传视频代码
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        that.setData({
          files: that.data.files.concat(res.tempFilePaths),
          haspicture: true
        });
        wx.showNavigationBarLoading()
        that.setData({
          loading: false,
          src: res.tempFilePath
        })
        var urlArr = new Array();
        // var urlArr={};
        console.log("res= " + res)
        var tempFilePath = res.tempFilePaths;
        console.log("tempFilePath= " + tempFilePath)

        var newDate = new Date();
        var newDateStr = newDate.toLocaleDateString();


        var extension = /\.([^.]*)$/.exec(tempFilePath);
        if (extension) {
          extension = extension[1].toLowerCase();
        }
        var name = "test." + extension;//上传的图片的别名      
        console.log(tempFilePath)
        var file = new Bmob.File(name, tempFilePath);
        console.log("name= " + name)
        file.save().then(function (res) {

          wx.hideNavigationBarLoading()
          var url = res.url();
          console.log("第1张Url" + url);

          that.setData({
            picture: url,
            
          })

          // if (imgLength == j) {
          //   console.log(imgLength, urlArr);
          //如果担心网络延时问题，可以去掉这几行注释，就是全部上传完成后显示。
          showPic(urlArr, that)
          // }

        }, function (error) {
          console.log(error)
        });

        console.log(file);


        //如果你突然发现这个文件传了又想立即删了，可以直接执行
        // file.destroy();


      }
    })

    return;

  },
  chooseImage2: function (e) {
    var that = this;
    // 注释这块是上传视频代码
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        that.setData({
          files2: that.data.files2.concat(res.tempFilePaths),
          hasdetailpicture: true
        });
        wx.showNavigationBarLoading()
        that.setData({
          loading: false,
          src: res.tempFilePath
        })
        var urlArr = new Array();
        // var urlArr={};
        console.log("res= " + res)
        var tempFilePath = res.tempFilePaths;
        console.log("tempFilePath= " + tempFilePath)

        var newDate = new Date();
        var newDateStr = newDate.toLocaleDateString();


        var extension = /\.([^.]*)$/.exec(tempFilePath);
        if (extension) {
          extension = extension[1].toLowerCase();
        }
        var name = "test." + extension;//上传的图片的别名      
        console.log(tempFilePath)
        var file = new Bmob.File(name, tempFilePath);
        console.log("name= " + name)
        file.save().then(function (res) {

          wx.hideNavigationBarLoading()
          var url = res.url();
          console.log("第1张Url" + url);

          urlArr.push({ "url": url });
          that.setData({
            detail_Pic: url
          })
          // if (imgLength == j) {
          //   console.log(imgLength, urlArr);
          //如果担心网络延时问题，可以去掉这几行注释，就是全部上传完成后显示。
          showPic(urlArr, that)
          // }

        }, function (error) {
          console.log(error)
        });

        console.log(file);


        //如果你突然发现这个文件传了又想立即删了，可以直接执行
        // file.destroy();


      }
    })

    return;

  },
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: picture // 需要预览的图片http链接列表
    })
  },
  previewImage2: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: detail_picture // 需要预览的图片http链接列表
    })
  },
  confirm: function (e) {//保存心情
    if (!this.data.shopName) {
      common.showTip("店名不能为空", "loading");
    }
    else if (!this.data.picture) {
      common.showTip("请上传封面图", "loading");
    }
    else {
      var that = this;
      var Shopping = Bmob.Object.extend("shopping");
      var shopping = new Shopping();
      shopping.set("timeStart", that.data.startDate);
      shopping.set("timeOff", that.data.endDate);
      shopping.set("shopname", that.data.shopName);
      shopping.set("place", that.data.shopAdd);
      shopping.set("picture", that.data.picture);
      shopping.set("detail_Pic", that.data.detail_Pic);
      shopping.set("detail", that.data.Report),
        shopping.set("tel", that.data.Tel);
      if (that.data.isSrc == true) {
        var name = that.data.src;//上传的图片的别名
        var file = new Bmob.File(name, that.data.src);
        file.save();
        shopping.set("picture", file);
      }
      shopping.save(null, {
        success: function (result) {

          // 添加成功，返回成功之后的objectId（注意：返回的属性名字是id，不是objectId），你还可以在Bmob的Web管理后台看到对应的数据

          wx.navigateBack({
            delta: 1
          });
        },
        error: function (result, error) {
          // 添加失败
          console.log(error)
          common.dataLoading("发布失败", "loading");
        }
      });
    }
  }
});
function showPic(urlArr, t) {
  t.setData({
    urlArr: urlArr
  })
}