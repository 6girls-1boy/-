// pages/pindan/add.js

var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    radioItems: [
      { name: '绿叶餐厅', value: '绿叶餐厅' },
      { name: '大学生活动中心', value: '大学生活动中心' },
      { name: '新食堂', value: '新食堂' }
    ],
    Event: "",
    shopName: "",
    date: "",
    time: "",
    place: ""
  },
  bindDateChange: function (e) {
    this.setData({
      date: e.detail.value
    })
  },
  bindTimeChange: function (e) {
    this.setData({
      time: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  radioChange: function (e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value);
    var radioItems = this.data.radioItems;
    for (var i = 0, len = radioItems.length; i < len; ++i) {
      radioItems[i].checked = radioItems[i].value == e.detail.value;
    }

    this.setData({
      radioItems: radioItems,
      place: e.detail.value
    });
  },
  confirmTyping1: function (e) {
    this.setData({
      shopName: e.detail.value
    });
  },
  confirmTyping2: function (e) {
    this.setData({
      Event: e.detail.value
    });
  },
  sendMessage: function () {
    if (!this.data.shopName) {
      wx.showToast({
        title: '店名不能为空',
        icon: 'loading',
        duration: 2000
      });
    }
    else if (!this.data.place) {
      wx.showToast({
        title: '请选择地点',
        icon: 'loading',
        duration: 2000
      });
    }
    else {
      var Pindan = Bmob.Object.extend("takeOut");
      var pindan = new Pindan();
      //添加数据，第一个入口参数是null
      pindan.save({
        willingDate: this.data.date,
        Shop_name: this.data.shopName,
        event: this.data.Event,
        time: this.data.time,
        place: this.data.place,
        tel:app.globalData.userTel,
        finished: "false",
      }, {
          success: function (result) {
            // 添加成功，返回成功之后的objectId（注意：返回的属性名字是id，不是objectId），你还可以在Bmob的Web管理后台看到对应的数据
            common.showTip("发布成功", "warining");
            wx.navigateBack({
            })
          },
          error: function (result, error) {
            // 添加失败
            wx.navigateTo({ url: 'msg_fail' });
          }
        })
    }
  }
})
