var Bmob = require('../../utils/bmob.js');

const WxParse = require('../../utils/wxParse/wxParse.js');
Page({
  data: {
    tel: ""
  },
  onLoad: function (e) {
    // 页面初始化 options为页面跳转所带来的参数

    console.log(e.objectId)
    var objectId = e.objectId;
    var that = this;
    // if (!e.objectId) {
    //   common.showTip("请重新进入", "loading");
    //   return false;
    // }

    var waimai = Bmob.Object.extend("takeOut");
    var query = new Bmob.Query(waimai);

    query.get(objectId, {
      success: function (result) {
        console.log(result);
        WxParse.wxParse('content', 'html', result.get("content"), that);
        that.setData({
          rows: result,
          tel: result.attributes.tel

        })
        // The object was retrieved successfully.        
      },
      error: function (result, error) {
        console.log("查询失败");
      }
    });
  },
  openFirstPage: function () {
    console.log(this.data.tel)
    wx.setClipboardData({
      data: this.data.tel,
    })



    wx.showToast({
      title: '成功！',
      icon: 'success',
      duration: 1500,
      success: function () {
        setTimeout(function () {
          //要延时执行的代码
          wx.switchTab({
            url: 'firstpage',
          })
        }, 1500)
      }
    });
  }
});