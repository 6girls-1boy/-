// pages/pindan/add.js

var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    Square: "",
    Name: "",
    Place: "",
    Price: "",
    Report: "无"
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  radioChange: function (e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value);
    var radioItems = this.data.radioItems;
    for (var i = 0, len = radioItems.length; i < len; ++i) {
      radioItems[i].checked = radioItems[i].value == e.detail.value;
    }

    this.setData({
      radioItems: radioItems,
      place: e.detail.value
    });
  },
  confirmTyping1: function (e) {
    this.setData({
      Name: e.detail.value
    });
  },
  confirmTyping2: function (e) {
    this.setData({
      Place: e.detail.value
    });
  },
  confirmTyping3: function (e) {
    this.setData({
      Square: e.detail.value
    });
  },
  confirmTyping4: function (e) {
    this.setData({
      Price: e.detail.value
    });
  },
  report:function(e){
    this.setData({
      Report:e.detail.value
    })
  },
  sendMessage: function () {
    var that=this;
    if (!this.data.Place) {
      common.showTip("地址不能为空", "loading");
    }
    else {
      var Pindan = Bmob.Object.extend("house");
      var pindan = new Pindan();
      //添加数据，第一个入口参数是null
      pindan.save({
        Square: this.data.Square,
        Price: this.data.Price,
        Preference:this.data.Report,
        Place: this.data.Place,
        Name: this.data.Name,
        tel:getApp().globalData.userTel,
        finished:"false"
      }, {
          success: function (result) {
            // 添加成功，返回成功之后的objectId（注意：返回的属性名字是id，不是objectId），你还可以在Bmob的Web管理后台看到对应的数据
            wx.showToast({
              title: '成功!',
              icon: 'success',
              duration: 1500,
              success: function () {
                setTimeout(function () {
                  //要延时执行的代码
                  wx.navigateBack({
                    
                  })
                }, 1500) //延迟时间
              }
            })
            
          },
          error: function (result, error) {
            // 添加失败
            wx.navigateTo({ url: 'msg_fail' });
          }
        })
    }
  }
})
