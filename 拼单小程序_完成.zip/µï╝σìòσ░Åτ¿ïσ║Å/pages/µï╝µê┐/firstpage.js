var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var app = getApp();
var that;

Page({
  data: {
    inputShowed: false,
    inputVal: "",
    pinfangList: [],
    limit: 10
  },
  onLoad: function () {
    that = this;

    wx.showShareMenu({
      withShareTicket: true //要求小程序返回分享目标信息
    })

    var k = 'http://bmob-cdn-12917.b0.upaiyun.com/2017/07/18/d99d3bb7400cb1ed808f34896bff6fcc.jpg';

    var newUrl = k.replace("http://bmob-cdn-12917.b0.upaiyun.com", "https://bmob-cdn-12917.bmobcloud.com")

    console.log(newUrl);
  },
  onShow: function () {
    getList(this);
  },
  openSuccess: function () {
    wx.navigateTo({
      url: 'msg_success'
    })
  },
  openFail: function () {
    wx.navigateTo({
      url: 'msg_fail'
    })
  },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
    getList(this);
  },
  clearInput: function () {
    this.setData({
      inputVal: ""
    });
    getList(this);
  },
  inputTyping: function (e) {
    getList(this, e.detail.value);
    this.setData({
      inputVal: e.detail.value
    });
  },
  toAdd:function(){
    wx.navigateTo({
      url: 'detail',
    })
  }

});

function getList(t, k) {
  that = t;
  var pinfang = Bmob.Object.extend("house");
  var query = new Bmob.Query(pinfang);
  var query1 = new Bmob.Query(pinfang);


  query.equalTo("Name", k);
  query.equalTo("finished", "false");

  //query.descending('createdAt');
  //query.include("own")
  // 查询所有数据
  //query.limit(that.data.limit);

  //var mainQuery = Bmob.Query.or(query, query1);
  var mainQuery = query;
  mainQuery.find({
    success: function (results) {
      // 循环处理查询到的数据
      console.log(results);
      that.setData({
        pinfangList: results
      })
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}
