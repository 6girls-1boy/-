var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var app = getApp()
Page({

  onLoad: function () {

  },
  formSubmit: function (event) {

    Bmob.User.logIn(event.detail.value.username, event.detail.value.paswd, {
      success: function (user) {
        wx.getStorage({
          key: Bmob._getBmobPath(Bmob.User._CURRENT_USER_KEY),
          success: function (res) {
            var Data = JSON.parse(res.data);
            app.globalData.userTel = Data.mobilePhoneNumber;
            wx.showToast({
              title: '登陆成功',
              icon: 'success',
              duration: 2000,
              success: function () {
                setTimeout(function () {
                  //要延时执行的代码
                  wx.switchTab({
                    url: '../pindan/firstpage'
                  })
                }, 1500) //延迟时间
              }
            })

          }
        })
      },
      error: function (user, error) {
        // The login failed. Check error to see why.
        console.log(error)
        common.showTip("输入错误", "loading");
      }
    });
  },
  register: function () {
    wx.navigateTo({
      url: '../register/register',
    })
  },

})