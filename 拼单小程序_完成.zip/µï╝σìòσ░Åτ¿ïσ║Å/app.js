//app.js
var Bmob = require('utils/bmob.js');
Bmob.initialize("fd72c7aef785d896526ee869994ae8bf", "f90f17086601c41030c66c8d1246c173");

App({

  onLaunch: function () {
  },
  globalData: {
    userInfo: null,
    aimAddress: "",
    userTel: ""
  }
})